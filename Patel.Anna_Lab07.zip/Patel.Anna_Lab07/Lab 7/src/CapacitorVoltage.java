/**
 * Data Processing (File I/O), Exception Handling. In this lab we will implement a program that inputs data from a file, processes this data, and then writes new data into a new output file. 
 */

/**
 * @author lhp618
 * @date 4/4/2022
 * @version 01
 *
 */
import java.util.Scanner;
import static java.lang.Math.exp;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
public class CapacitorVoltage {

		public static void main(String[] args) throws Exception {
			CapacitorVoltage.calculate();
		}
		
		public class CapacitorVoltage {
			static Scanner txtFileScan; 
			static Scanner terminalScan = new Scanner(System.in);
			static PrintWriter writer; 
			
			public static void calculate() throws FileNotFoundException {
				while (true) {														// gets input and outputs. 
					System.out.println("Please enter your input file path");
	                String inputPath = terminalScan.nextLine();						// terminalScan gets the input.
	                System.out.println("Please enter your output file path");
	                String outputPath = terminalScan.nextLine();					// terminalScan gets the output.			
	                
	                try {
	                	 txtFileScan = new Scanner(new File(inputPath)); 
	                     writer = new PrintWriter(new File(outputPath));
	                }
	                
	                catch (FileNotFoundException e) {
	                	System.out.println("Invalid path entered. Please enter a valid path.\n");
	                    continue;
	                }
	                break;
				}
				double[] in = new double[5];
				
				for (int i = 0; txtFileScan.hasNext(); i++)
					in[i] = txtFileScan.nextDouble();
				double B = in[0], R = in[1], C = in[2], t_low = in[3], t_high = in[4];
				
				 for (int i = (int)t_low; i < t_high; i += t_high / 100)
		             writer.write("T: " + i + " Result: " + (B * (1 - exp(-i / (R * C))) + "\n"));
				 
				 txtFileScan.close();
		         terminalScan.close();
		         writer.close();
			}
		}
}
