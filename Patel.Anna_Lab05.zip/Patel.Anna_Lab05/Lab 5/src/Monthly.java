/**
 * Class object that is an appointment that occurs every month. Extended from Appointment superclass. 
 */

/**
 * @author lhp618
 * @date 3/21/2022
 * @version 01
 */
public class Monthly extends Appointment {
	
	 public Monthly (int year, int month, int day, String description) {
	        super(year, month, day, description);
	 }			// the contructor that is implemented to initialize important information from the appointment. 
	 
	 @Override
	 public boolean occursOn(int year, int month, int day) {
	        if (this.day == day && (this.year >= year && this.month >= month)) { return true; } else { return false; }
	 }		// if the date from the input is the same as the date of the object then the boolean occursOn method will return true. 
	 
	 @Override
	 public String toString() {
	        return "Monthly[" + description + " Date: " + year + "/" + month + "/" + day + "]";
	 }


}
