/**
 * 
 */

/**
 * @author user
 *
 */
public interface Sequence 
{
   int next();
}