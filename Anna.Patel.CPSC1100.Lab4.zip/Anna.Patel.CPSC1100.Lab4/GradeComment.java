/**
 * This program comments on the grade. 
 */
/**
 * 
 * @author lhp618
 * 9/23/2021
 * version 1.0
 *
 */
import java.util.Scanner;
public class GradeComment {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in); // s is declared as an object of scanner class. 
		
		System.out.println("Please enter your letter grade A, B, C, or D: "); // input for user. 
		char lGrade = (s.next()).charAt(0); // first character of string is assigned to a char. 
		String comment; // string object is applied in switch statement. 
		
		
		switch(lGrade) { // switch statement made for char lGrade. 
		case 'A': comment = "Awesome job!!!";
		break; // break is optional but recommended to prevent the remainder of the switch statement.  
		case 'B': comment = "Good job!"; // switch statement is the shorter version of an if/else statement. 
		break;
		case 'C': comment = "You can do better!";
		break;
		case 'D': comment = "See you next term!";
		break;
		default: comment = "Why are you here?"; // default is optional as well and is applied when none of the cases align with the switch statement. 
		}
		
		/*
		if (lGrade == 'A') {
			comment = "Awesome job!!!";
		} else {
			if (lGrade == 'B') {
				comment = "Good job!";
			} else {
				if (lGrade == 'C') {
					comment = "You can do better!";
				} else {
					if(lGrade == 'D') {
						comment = "See you next term!";
					} else {
						comment = "Why you are here?";
			    }
	     	}
		}
	} 
		*/
		
		
		
		
	System.out.println(comment); // the comments listed are printed for user. 
	s.close(); // scanner s closed. 

	}

}
