/**
 * This program reads a line of input as a string and prints what is asked. 
 */

/**
 * @author lhp618
 * @date 10/7/2021
 * @version 1.0
 *
 */
import java.util.Scanner;
public class LoopStatement {

	public static void main(String[] args) {
		// 1. scanner.
		Scanner scan = new Scanner(System.in);
		
		// 2. a.) only the uppercase letters in the string. 
		System.out.print("Please enter a sentence: "); // for user input.
		String str = scan.nextLine(); // string is used for this loop statement. 
		int i; // int i; is declared within the loop. 
		for(i = 0; i < str.length() ; i++) {
			char c = str.charAt(i);
			if( c >= 'A' && c <= 'Z') // loop statement is used to find what is needed from the string. for each part, a different block is needed in the loop. 
				System.out.print(c);		
		}
		
		// 3. b.) every second letter of the string.
		System.out.println("\n");
		for(i = 0; i < str.length() ; i++) {
			char c = str.charAt(i); // everything is the same up until the if statement in this loop statement. 
			if( i%2 == 1 )	// every second letter of the string is printed if the condition is right. 
				System.out.print(c);	
		}		
		
		// 4. c.) the string, with all vowels replaced by an underscore. 
		System.out.println("\n");
		for(i = 0; i < str.length() ; i++) {
			char c = str.charAt(i);
			if ((c == 'a') || (c == 'A') ||(c == 'e') || (c == 'E')||(c == 'i') || (c == 'I')||(c == 'o') || (c == 'O')||(c == 'u') || (c == 'U')) 
				c = '_'; // all of the vowels are included in the if statement and then will be printed as underscore. 
			System.out.print(c);
		}		
		
		// 5. d.) the number of vowels in the string. 
		System.out.println("\n"); // \n is used so that every result prints to the next line. 
		int count = 0;
		for(i = 0; i < str.length() ; i++) {
			char c = str.charAt(i);
			if ((str.charAt(i) == 'a') || (str.charAt(i) == 'A') ||(str.charAt(i) == 'e') || (str.charAt(i) == 'E')||(str.charAt(i) == 'i') || (str.charAt(i) == 'I')||(str.charAt(i) == 'o') || (str.charAt(i) == 'O')||(str.charAt(i) == 'u') || (str.charAt(i) == 'U')) 
			{
				count++; // the number of vowels will be printed with this possible statement. 
			}
			System.out.print(count);
		}		
			
		// 6. e.) the positions of all vowels in the string. 
		System.out.println("\n");
		for(i = 0; i < str.length() ; i++) {
			char c = str.charAt(i);
		}
		
		// 7. close scanner.
		scan.close();
	}// main

}// class
