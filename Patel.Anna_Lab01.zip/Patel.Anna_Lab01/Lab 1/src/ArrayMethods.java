/**
 * Array methods 
 * 
 * @name lhp 618
 * @date 1/24/2022
 * @version 01 
 * 
 * 
 */
import java.util.Arrays;
import java.util.Random;


public class ArrayMethods {

	//***NOTE that these methods will change the array itself


	//part a, fill in this method
	public static void swapFirstAndLast(int[] values) {		// this method will swap the first and last elements from the initial set. 
		// save the first element to a temp var. 
		int temp = values[values.length-1];
		//move the last element to the first position
		values[values.length-1] = values[0];
		values[0] = temp;
		// now put the saved first element into the last position

	}

	//part b, fill in this method
	public static void shiftRight(int[] values) {		// every element will be shifted to the right in this method. 
		int temp = values[values.length-1];
		for (int i = values.length-1; i>0; i--) {
			values[i] = values [i-1];
			
		}
		values [0] = temp; 

	}

	//part c, set all even elements to 0.
	public static void setEvensToZero(int[] values) {
		for(int i = 0; i < values.length; i++)
		{
			if(values[i]%2 == 0)	// even elements are set to zero by using the for loop. 
			{
				values[i] = 0;
			}
		}

	}

	//part d, replace each element except the first and last by larger of two 
	//around it
	public static void largerOfAdjacents(int[] values) {		// the larger of the adjacent elements will be printed
		int[] temp = new int [values.length];
		temp [0] = values [0];
		temp [values.length-1] = values [values.length-1];
		for(int i = 1; i < values.length-1; i++) {
			if(values[i-1] > values[i+1])
				temp[i] = values[i-1];
			else 
				temp[i] = values[i+1];
		}
		//values = Arrays.copyOf(temp, temp.length); 
		for(int i = 0; i < values.length; i++) {
			values[i] = temp[i];
			
		}
		
	}
	
	
	//part e, remove middle el if odd length, else remove middle two els.
	public static int[] removeMiddle(int[] values) {
		int size = values.length;
		int newValues[];
		if(size % 2 ==0) {
		    newValues = new int[size-2];
		    for (int i = 0; i < (newValues.length/2); i++) {
		        newValues[i] = values[i];
		       
		    }
		    for (int i = (newValues.length/2); i < newValues.length; i++) {
		        newValues[i] = values[i+2];
		       
		    }
		}
		else {
		    newValues = new int[size-1];
		    for(int i = 0; i < (newValues.length/2); i++) {
		        newValues[i] = values[i];
		       
		    }
		    for (int i = (newValues.length/2); i < newValues.length; i++) {
		        newValues[i] = values[i+1];
		       
		    }
		}
		return values; 		
	}


	//part f - move all evens to front
	public static void moveEvensToFront(int[] values) {
		int temp = 0;
		int a = 0; 
		for (int i = 0; i < values.length; i++) {
			if (values[i]%2==0) {
				for (int j = i; j > a; j--) {
					temp = values[j-1];
					values[j-1] = values[j];
					values[j] = temp; 
				}
				a++; 
			}
		}

	}

	//part g - return second largest element in array
	public static int ret2ndLargest(int[] values) {
		Arrays.sort(values);
		return values[values.length - 2]; 
	}

	//part H - returns true if array is sorted in increasing order 
	public static boolean isSorted(int[] values) {			// boolean is used to see if the array elements are sorted in an increasing order. if the arrays are sorted in an increasing order then the condition is true. 
		for(int i = 0 ; i < values.length - 1 ; i++)
		{
			if(values[i+1] >= values[i])
			{	
				continue;
			}
			else
			return false;
		}
	return true;

	}

	//PART I - return true if array contains 2 adjacent duplicate values
	public static boolean hasAdjDuplicates(int[] values) {	// a boolean method is needed just as the isSort. 
		for(int i = 0 ; i < values.length - 1; i++)
		{
			if(values[i+1] != values[i])
			{	
				continue;
			}
			else
			return true;
			}
	
		
		return false; //dummy return value
	}


	//PART J - return true if array contains 2 duplicate values
	public static boolean hasDuplicates(int[] values) {
		for(int i = 0; i < values.length ; i++)		// a nested loop is created to compare each element for the second loop. if the second loop finds similarities then the condition is true therefore the return is true. 
		{
			for(int j = 0; j < values.length; j++)
			{
				if(i == j)
					continue;
				else if(values[i] == values[j])
					return true;
			}
		}
		return false;
	}
	
	
}
