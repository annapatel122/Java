/**
 * Car class is basically the subclass of the Vehicle super class. It inherits efficiency and the printMessage and getName methods. 
 */

/**
 * @author lhp618
 * @date 3/29/2022
 * @version 01
 *
 */
public class Car extends Vehicle {

	public Car(double efficiency) {
		super (efficiency);

	}
	public void printMessage() {
	        System.out.println("I am a Car. VROOOM!");
	    }

	public String getName() { return "Car"; }
}
