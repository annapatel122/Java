import java.util.Scanner;

public class VirtualAddress {
	private static final int MIN_PAGE_SIZE = 9;
	private static final int MAX_PAGE_SIZE = 14;
	private static final int MIN_ADDR = 0;
	private static final int MAX_ADDR = 32;		// these private static variables declared will be finalized in order to print out of the size of the virtual system. 
	
	private static void clearBuf(Scanner in)	// this will clear up the buffer when needing user input. 
	
	{
		in.nextLine();
	}


private static int powerOfTwo(long n)

{
	
if (n == 0)
      return -1;

int count = 0;
while (n != 1) {		// while loop to count the power of the sizes. 

      if ((n % 2) == 0)

      {
          n /= 2;
          count += 1;
      }
      else
      {

          return -1;
      }

}

return count;

}

private static boolean isValidPageSize(long pageSize)

{



int power = powerOfTwo(pageSize);



if ((power == -1) || (power < MIN_PAGE_SIZE) || (power > MAX_PAGE_SIZE))

{

      System.out.println("Invalid page size. Please enter "

               + "a value that must be a power of 2 and between " +

               (int) Math.pow(2, MIN_PAGE_SIZE)

               + " and " + (int) Math.pow(2, MAX_PAGE_SIZE));

      return false;			// this will print out the page size of the virtual system. 

}



return true;

}


private static boolean isValidVirtualAddr(long virtualAddr)

{

// Check if virtual address is valid

if ((virtualAddr < 0) || (virtualAddr > ((long)Math.pow(2, 32) - 1)))

{

      System.out.println("Invalid virtual address. "

               + "Please enter a value between " + MIN_ADDR

               + " and " + ((long) Math.pow(2, MAX_ADDR) - 1));

      return false;

}



return true;

}


public static void main(String[] args)

{



Scanner in = new Scanner(System.in);  		// scanner object for user input. 



long pageSize;		// Gets page size.

do

{

      System.out.println("Please enter the system page size:");

      pageSize = in.nextLong();

      

      clearBuf(in);

} while (!isValidPageSize(pageSize));



long virtualAddr;

do

{

      System.out.println("Please enter the virtual address:");

      virtualAddr = in.nextLong();


      clearBuf(in);

} while (!isValidVirtualAddr(virtualAddr));


in.close();


System.out.println("This address is in virtual page:\n"

          + (virtualAddr / pageSize));		// displays virtual page size. 





System.out.println("At offset:\n" + (virtualAddr % pageSize));		// offset is displayed. 

}

}