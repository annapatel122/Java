/**
 * Class object that is an appointment that occurs everyday. Extended from Appointment superclass. 
 */

/**
 * @author lhp618
 * @date 3/21/2022
 * @version 01
 */
public class Daily extends Appointment {
	
	public Daily (int year, int month, int day, String description) {
       super(year, month, day, description);
    }				// the contructor that is implemented to initialize important information from the appointment. 
	
	 @Override
	 public boolean occursOn(int year, int month, int day) {
	    if (this.day < day && this.month <= month && this.year <= year) { return false; } else { return true; }
	}		// if the date from the input is the same as the date of the object then the boolean occursOn method will return true. 
	 
	 @Override
	 public String toString() {
	    return "Daily[" + description + " Date: " + year + "/" + month + "/" + day + "]";
	}

}
