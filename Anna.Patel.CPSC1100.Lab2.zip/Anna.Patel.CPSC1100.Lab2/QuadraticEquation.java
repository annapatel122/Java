/*
 * This program computes the the roots of a quadratic equation 
 */
/**
 * 
 * @author lhp618
 * @date 9/2/2021
 * @version 1.0
 *
 */
import java.util.Scanner;
// java.util.Scanner needs to be imported or else System.out.printIn would not function.

public class QuadraticEquation {

	public static void main(String[] args) {
		// 1. create a scanner object
		Scanner anyName = new Scanner(System.in);
		// always include java.util.Scanner or else this program would not function.
		
		// 2. declare variables 
		double a, b, c, disc;
		// these are the variables that will be entered by the user.
		
		// 3. prompt user for inputs
		System.out.println("Enter a, b, c, seperated by space: ");
		a = anyName.nextDouble();
		b = anyName.nextDouble();
		c = anyName.nextDouble();
		// the a, b, and c need to be entered without commas so seperated by space is included.
		
		// 4. do computations 
		disc = b*b - 4*a*c;
		// the disc is the discriminate used in java to calculate it. 
		
		if(disc > 0) {
			System.out.print("The equation has two roots: ");
			double root1 = (-b + Math.sqrt(b*b - 4*a*c))/(2*a);
			double root2 = (-b - Math.sqrt(b*b - 4*a*c))/(2*a);
			System.out.print("The equation has two roots: " + root1 + ", " + root2);
			// the equation above is used if there are two roots and the System.out.printIn gives the result of two roots from the equation.
		}
		else if (disc == 0) {
			double root = (-b)/(2*a);
			System.out.print("The equation has one root: " + root);
			// only one root will be the result since there is one equation. 
		}
		else {
			System.out.print("The equation has no real roots");
			// no roots will appear if the calculation says so.
			
		}
		
		//5. close the scanner 
		anyName.close();

	}

}
