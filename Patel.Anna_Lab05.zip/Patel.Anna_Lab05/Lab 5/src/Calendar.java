import java.util.ArrayList;

/**
 * Implemented for users to be able to make or remove appointments.  
 */

/**
 * @author lhp618
 * @date 3/21/2022
 * @version 01
 */
public class Calendar {
	
	private ArrayList<Appointment> appointments = new ArrayList<Appointment>();
	// array list implemented to list the appointments made. 
	
	
	public void add(Appointment appt) {		// add appointments. 
		appointments.add(appt);
	}


	public void remove(int year, int month, int day) {
		int i = 0; 
		while (i < appointments.size()) {
			if (appointments.get(i).occursOn(year, month, day)) appointments.remove(i);
			else i++; 
		}			// removes appointments depending on the dates. 
		
	}
	
	public String toString() {
        String result = "";
        for (Appointment appt : appointments) {
            result += appt.toString() + "\n";
        }
        return result;
    }			// the string contains information of every appointment in the list. 

}
