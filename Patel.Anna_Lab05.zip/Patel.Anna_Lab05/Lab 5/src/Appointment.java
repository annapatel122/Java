/**
 * Superclass for different appointment types. 
 */

/**
 * @author lhp618
 * @date 3/21/2022
 * @version 01
 */
public abstract class Appointment {

	
		 public int year;				// details about the appointments listed as variables. 
		 public int month;
		 public int day;
		 public String description;
	


	public Appointment (int year, int month, int day, String description) {
		 this.year = year;				// constructor for the superclass to initialize the details for the appointment. 
	     this.month = month;
	     this.day = day;
	     this.description = description;	

	}
	
	public abstract boolean occursOn(int year, int month, int day);			// an abstract method to make sure all the objected inherited include the methods. 

}
