/*
 This program computes the volume of a sphere
 */

/**
 * 
 * @author lhp618
 * @date 08/26/2021
 * @version 1.0
 *
 */
import java.util.Scanner;
// java.util.Scanner is important since it obtains input of int, double, and strings.

public class Sphere {

	public static void main(String[] args) {
		// public static void main(String [] args) is a main method that is needed in any type of java program. Its an array of sequences of strings that are sent to the main method.
		// 1. define variables 
		double radius;
		// double radiusInMeters; 
		double volume;
		// double type is more precise for computations even though it takes more space.

		// 2. create a scanner object 
		Scanner s = new Scanner(System.in);
		// in Scanner s, the s is declared as an object of the Scanner class. System.in tells java that the input will go into the system. 
		
		// 3. read input from user 
		System.out.print("Enter sphere radius in inches: "); 
		// System.out.print(...); method is used so that output of the statements would result in the same line. 
		radius = s.nextDouble(); 
		// radius = s.nextDouble(); statement is used to input the values of the integer variable radius from user. nextDouble() is a method of the object s of the scanner class. 
		
		// 4. do computations 
		// radiusInMeters = radius * 0.0254;
		radius = radius * 0.0254; 
		// radius will be in inches but after computations it will be converted to meters. 
		
		
		//System.out.print("The sphere radius in meters is: " + radius);
		
		// compute the volume (4/3) . Pi . r . r . r
		volume = (4.0/3)*Math.PI*radius*radius*radius;
		// a decimal needs to be used to compute volume as it is a double type variable. 
		// System.out.printIn(4/3);
		// volume = (4/3)*Math.PI*Math.pow(radius, 3)
		
		
		// 5. output radius
		System.out.print("The volume of the sphere is: " + volume + " cubic meters");
		// this will determine the output results. 
		
		// 6. close the Scanner object 
		s.close();
		// this will help close the stream involved with the scanner object. 
		
	
	}
	
}
				