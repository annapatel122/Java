/**
 * PrimeSequence is the implementation of the interface Sequence. 
 */

/**
 * @author lhp618
 * @date 3/29/2022
 * @version 01
 *
 */
public class PrimeSequence implements Sequence {

	public int next() {
		if (n == 2) {			// 2 is returned while the n is set to 1. 
	            n = 1;				// n is set to 1 on the loop to avoid skipping 3.
	            return 2;
	    }

	      
	    do { n += 2; } while (!isPrime(n)); 		// set to += for the prime numbers. 
	    return n;
		
	}


	boolean isPrime(int n) {		// boolean that makes sure if a number is divisible. 

        for (int i = 3; i < n; i++)			// since += was already used, the loop will start with 3. 
            if (n % i == 0) return false;

        return true;
    }

}
