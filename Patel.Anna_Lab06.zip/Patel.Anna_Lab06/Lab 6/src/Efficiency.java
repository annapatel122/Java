/**
 * Interface that assists with the inheritance of getEfficiency method. 
 */

/**
 * @author lhp618
 * @date 3/29/2022
 * @version 01
 *
 */
public interface Efficiency {			// interface for efficiency
	double getEffciency();
}
