/**
 * Java program that uses synchronization techniques to simulate the sharing of a single ball among 3 
groups of children on the playground (You may think of these as the �red team�, �blue team�, and �white team�).
 */

/**
 * Project 4-2 
 */
package multithreading; 		// created a multithread program for this problem. 

import java.util.logging.Level;
import java.util.logging.Logger;

class Ball {
	
}

class MyThread extends Thread {

	public String name;
	private int count = 0;		// created a private count of 0. 
	Ball ball;

	MyThread(String n, Ball ball) {
		name = n;
		this.ball = ball;		// the ball is initialized in the thread. 
	}
@Override
public void run() {
	while (count < 5) {		// through the while loop, the game runs 5 times. 
	System.out.println(name + " wants the ball. Turn #" + (count + 1));
		synchronized (ball) {
			System.out.println(name + " team is playing with ball. Turn #" + (count + 1));
			try {
				sleep((long) (1000 * Math.random()));		// through synchronization, the game of the ball between the teams starts. 
				} 		
			catch (InterruptedException ex) {
			Logger.getLogger(MyThread.class.getName()).log(Level.SEVERE, null, ex); 	// thread for if a team catches the ball. 
		}
	  }
		System.out.println(name + " team is done playing with ball. Turn #" + (count + 1));			// the game continues by a count of 1. 
		count++;
		}
	}
}


