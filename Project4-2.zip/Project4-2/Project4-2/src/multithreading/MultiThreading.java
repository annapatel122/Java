package multithreading;

public class MultiThreading {					// multithread class implemented to create the threads for the different balls used during the game. 
	public static void main(String[] args) {
		Ball ball = new Ball();
		MyThread t1 = new MyThread("Blue", ball);
		MyThread t2 = new MyThread("White", ball);
		MyThread t3 = new MyThread("Red", ball);
		t1.start();
		t2.start();
		t3.start();
	}
}
