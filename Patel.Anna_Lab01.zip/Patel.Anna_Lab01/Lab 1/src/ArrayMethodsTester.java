/**
 * Array methods tester
 * 
 * @name lhp 618
 * @date 1/24/2022
 * @version 01 
 * 
 * 
 */
import java.util.Arrays;
import java.util.Random;


public class ArrayMethodsTester {

	//helper method to print an array
	public static void printArray(int[] values) {
		System.out.println(Arrays.toString(values));
	}
	public static void main(String[] args) {

		//In your main method you should test your array methods
		//Create an array of size 10
		//****** HERE
		final int SIZE = 10;
		int[] a = new int [SIZE]; // array of size 1
		
		//**** Fill the array with random values (use a loop, and a
		//Random object)
		
		for(int i = 0; i < a.length; i++) {
			a[i] = (int)(Math.random()*(100-0+1));
		}
		
		//Now print the array to show initial values
		System.out.println("Initial Array:");
		//note the usage of the "toString()" method here to print the array
		System.out.println(Arrays.toString(a));
		//Could replace the previous line with this:
		//printArray(testValues);
		//blank line
		System.out.println();


		//Test methods below this line.
		
		
		// A.)
		//Test of swapFirstAndLast()
		System.out.println("Before call to swapFirstAndLast():");
		printArray(a);
		//swap first and last element
		//this method modifies the array referenced by "testValues"
		ArrayMethods.swapFirstAndLast(a);
		System.out.println("After call to swapFirstAndLast()");
		printArray(a); //printing the same array but it has changed
		System.out.println();
		
		
		
		
		// B.)
		System.out.println("Before call to shiftRight():");
		printArray(a);
		// shift all the elements to the right 
		//this method modifies the array referenced by "testValues"
		ArrayMethods.shiftRight(a);
		System.out.println("After call to shiftRight():");
		printArray(a); //printing the same array but it has changed
		System.out.println();

		//continue with tests as you complete methods ...
		
		
		
		
		// C.)
		System.out.println("Before call to setEvensToZero():");
		printArray(a);
		//set even elements to zero
		//this method modifies the array referenced by "testValues"
		ArrayMethods.setEvensToZero(a);
		System.out.println("After call to setEvensToZero():");
		printArray(a); //printing the same array but it has changed
		System.out.println();
		
		
		
		// D.)
		System.out.println("Before call to largerOfAdjacents():");
		printArray(a);
		// this will print out the larger of the adjacent elements.  
		//this method modifies the array referenced by "testValues"
		ArrayMethods.largerOfAdjacents(a);
		System.out.println("After call to largerOfAdjacents():");
		printArray(a); //printing the same array but it has changed
		System.out.println();
		
		
		// E.)
		System.out.println("Before call to removeMiddle():");
		printArray(a);
		// this will remove the middle elements
		//this method modifies the array referenced by "testValues"
		ArrayMethods.removeMiddle(a);
		System.out.println("After call to removeMiddle():");
		printArray(a); //printing the same array but it has changed
		System.out.println();

		
		// F.)
		System.out.println("Before call to moveEvensToFront():");
		printArray(a);
		//this will move all the even elements to the front 
		//this method modifies the array referenced by "testValues"
		ArrayMethods.moveEvensToFront(a);
		System.out.println("After call to moveEvensToFront():");
		printArray(a); //printing the same array but it has changed
		System.out.println();
		
		
		// G.) 
		System.out.println("Before call to ret2ndLargest():");
		printArray(a);
		// this will return the second largest elements
		//this method modifies the array referenced by "testValues"
		ArrayMethods.ret2ndLargest(a);
		System.out.println("After call to ret2ndLargest():");
		printArray(a); //printing the same array but it has changed
		System.out.println();
		
		
		
		// H.)
		System.out.println("Before call to isSorted():");
		printArray(a);
		// this will sort out the elements
		//this method modifies the array referenced by "testValues"
		ArrayMethods.isSorted(a);
		System.out.println("After call to isSorted():");
		printArray(a); //printing the same array but it has changed
		System.out.println();
		
		
		// I.)
		System.out.println("Before call to hasAdjDuplicates():");
		printArray(a);
		// this will print the adjacent duplicates of the elements
		//this method modifies the array referenced by "testValues"
		ArrayMethods.hasAdjDuplicates(a);
		System.out.println("After call to hasAdjDuplicates():");
		printArray(a); //printing the same array but it has changed
		System.out.println();
		
		
		// J.)
		System.out.println("Before call to hasDuplicates():");
		printArray(a);
		//this will print the duplicates of the elements 
		//this method modifies the array referenced by "testValues"
		ArrayMethods.hasDuplicates(a);
		System.out.println("After call to hasDuplicates():");
		printArray(a); //printing the same array but it has changed
		System.out.println();
		

	}

}
