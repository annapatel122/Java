/**
 * Implements a SubstringGenerator (class) that generates all substrings of a string 
recursively.  
 */

/**
 * @author lhp618
 * @date 04/18/2022
 * @version 01
 *
 */
import java.util.ArrayList;
/**
 * This class generates substrings of a string.
 */
public class SubstringGenerator {
	public static ArrayList<String> getSubstrings(String word) {	// substring for the different words. 
		ArrayList<String> result = new ArrayList<String>();	// this will store strings for object result. 
		result.add(""); // return values. 
		
		return result;	// returns all of the values. 
	}
	private static ArrayList<String> findAllSubstrings(ArrayList<String> strings, int letter, int travel, String word) {		// all strings are stored. 
		if (letter == word.length())		// the number of words/letters. 
			return strings;
		if (letter == travel)
			return findAllSubstrings(strings, letter += 1, word.length(), word);
		strings.add(word.substring(letter, travel));
		return findAllSubstrings(strings, letter, travel -= 1, word);
	}
}