/**
 * Vehicle class serves as the super class that determines the behavior of every vehicle.  
 */

/**
 * @author lhp618
 * @date 3/29/2022
 * @version 01
 *
 */
public class Vehicle implements Efficiency {
	 public double efficiency;

	    public Vehicle(double efficiency) {				// constructor for superclass. 
	        this.efficiency = efficiency;
	    }

	    public void printMessage() {							// prints the text. 			
	        System.out.println("I am a Vehicle. VROOOM!");
	    }

	    public String getName() { return "Vehicle"; } 

	    public double getEfficiency() { return efficiency; }		// name and efficiency are returned. 


		public double getEffciency() {

			return 0;
		}

}
