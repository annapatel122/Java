/**
 * Using Recursion, write a program to compute the sum of all values in 
an array.
 */

/**
 * @author lhp618
 * @date 04/11/2022
 * @version 01
 *
 */
import java.util.Scanner;
/**
 * Greek's method to approximate the square root of a given number.
 */
public class SquareRootComputer {
	public class Tester {		// tester class.
		public static void main(String[] args) {
			int[] numbers = new int[] { 5, 5, 5, 5, 5, 5, 5 };	// numbers needed. 
			int result = Part1.computeAllValuesInArray(numbers);	// recursive method. 
			System.out.println(result); 		// output. 			


		    Scanner scan = new Scanner(System.in);	// scanner object. 
			
			System.out.println("Enter a number: ");	// input from user. 
			double input = scan.nextDouble();
		    System.out.println(Part2.squareRoot(input));
		    
		    scan.close();	// scanner closed. 
		    
		}
	}
	public class Part1 {
		public static int computeAllValuesInArray (int[] input) {		// helper method used to find the sum of all values in the array. 
			return computeAllValuesInArrayRec(input, 0, 0);
		}
		public static int computeAllValuesInArrayRec (int[] input, int step , int total) {		// recursive method used to find the sum of all values in the array. 
	        if (step == input.length) return total;
	        return computeAllValuesInArrayRec(input, step + 1, total + input[step]);		// recursive method. 
	        }
		
	}
	public class Part2 {
		public static double squareRoot(double x) {		// helper method. 
            if (x < 1) return 0.0;
            return squareRootGuess(x, x);
		}
		private static double squareRootGuess(double x, double g) {		// recursive function that finds the square root of a number. 
			if (Math.abs(x - (g * g)) < 0.001) return g;
            return squareRootGuess(x, (g + (x / g)) / 2);
		}
	}
}