/**
 * Tester class for arrays, loops, and methods. 
 */

/**
 * @author lhp618
 * @date 3/29/2022
 * @version 01
 *
 */
import java.util.Random;
public class Tester {
	 public static void main(String[] args) throws Exception {

	        final int NUM_VEHICLES = 10;				// number of vehicles. 
	        Vehicle[] vehicles = new Vehicle[NUM_VEHICLES];			// where the vehicle data will be stored. 
	        Random rand = new Random();				// random number generator. 

	        for (int i = 0; i < vehicles.length; i++) {			// create different cases of the amount of vehicles. 
	            switch (rand.nextInt(0, 3)) {					// the switch statement that states if the value is 0 then it is vehicle and if it is 1, it will create car. 
	                case 0: 
	                    vehicles[i] = new Vehicle(rand.nextInt(0, 100));		// afterwards there are different cases for the switch statement. 
	                    break;
	                case 1: 
	                    vehicles[i] = new Car(rand.nextInt(0, 100));
	                    break;
	                case 2:
	                    vehicles[i] = new Boat(rand.nextInt(0, 100));
	                    break;
	                default: System.out.println("your rand statement is wrong.");
	                    break;
	            }
	        }

	       
	        for (Vehicle v : vehicles) {
	            v.printMessage();
	        }

	        System.out.println();

	     
	        for (Vehicle v : vehicles) {
	            System.out.println(v.getName() + ": " + v.getEfficiency());
	        }																		// iterates every vehicle and prints their messages and names. 

	        System.out.println();

	        
	        int threshhold = 20;			// threshold variable that controls the methods. 
	       
	        Vehicle eff = (Vehicle)getFirstBelowT(vehicles, threshhold);

	        if (eff == null) 
	            System.out.println("There were no efficiencies smaller than " + threshhold); 
	        else    
	            System.out.println("The first object with efficiency less than " + threshhold + " was " + eff.getName() + " with efficiency of " + eff.getEfficiency() + ".");
	    }


	    public static Efficiency getFirstBelowT(Efficiency[] efficiency, double threshhold) {			// iterates every object. 
	        for (Efficiency e : efficiency) 
	            if (e.getEffciency() < threshhold) return e;				// makes sure that efficiency is less than the threshold and if not it would return null.

	        return null;
	    }
}
