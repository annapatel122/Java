/*
 This program computes taxes.
 */

/**
 * 
 * @author lhp618
 * @date 09/16/2021
 * @version 1.0
 *
 */
import java.util.Scanner;
public class Taxes {

	public static void main(String[] args) {
		// 1. declare variables 
		final double RATE1 = 0.10;
		final double RATE2 = 0.15;
		final double RATE3 = 0.25; // all of the tax rates need to be declared as final double since it is constant.
		double income; // income is declared as double since it will change depending on the users. 
		double tax; // tax is declared as double since it can change too along with the income of the users. 
		int status; // status of the user is declared as integer because for single it is 0 and for married it is 1. integer is used because there obviously is no decimal needed for it as it is a whole number either 0 or 1. 
	
	
		
		// 2. create a scanner object
		Scanner in = new Scanner(System.in);
		
		// 3. inputs 
		System.out.print("Enter the status (0 for S or 1 for M) = "); // the user will input the status as either 0 for S or 1 for M.
		status = in.nextInt();
		
		
		System.out.print("Enter the income"); // the user will input their income. 
		income = in.nextDouble();
		
		// 4. computations 
		if (status == 0) { // the if statement started off with the status for S.
			if(income <= 8000) {tax = income * 0.10;} // the if statement for income started off with <= 8000 until the income raised. 
			else if(income <= 32000) {tax = 800 + (income - 8000)*0.15;} // as the income is raised, else if statement is used.
			else {tax = 4400 + (income - 32000)*0.25;} // tax is declared so computations will work. lastly, else is used for final computation for S. 
		}
		else { // the else is for M status. 
			if(income <= 16000) {tax = income * 0.10;} // the if statement for M is similar to the S. same goes for the else if and else. 
			else if(income <= 64000) {tax = 1600 + (income - 16000)*0.15;}
			else {tax = 8800 + (income - 64000)*0.25;}
		}
		
		// 5. output tax 
		System.out.println("Your income tax is: $" + tax); // the income tax is computed for the user. 
		
		// 6. close the scanner object 
		in.close();
	}

}
